var spApp = angular
                .module("spApp", [])
                .controller("viewItemsController", function ($scope, $http) {
                    var url = _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/getByTitle('Timeline')/items?$select=Title,Driving_x0020_Demand_x0020_Chann,Event_x0020__x0028_CAM_x0029_,Launch_x0020_Month,Category,CIME,Campaign_x0020_Name";
                    $http(
                    {
                        method: "GET",
                        url: url,
                        headers: { "accept": "application/json;odata=verbose" }
                    }
                    ).success(function (data, status, headers, config) {
                        $scope.details = data.d.results;
						
                    }).error(function (data, status, headers, config) {
                    });
                    
                })